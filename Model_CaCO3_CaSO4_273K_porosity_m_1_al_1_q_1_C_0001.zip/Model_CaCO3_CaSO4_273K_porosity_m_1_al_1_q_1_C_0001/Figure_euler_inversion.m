n = importdata('output_nodal_variables_vs_x.dat');
e = importdata('output_element_materials_vs_x.dat');
u_simulated = n(101:101:101000, 9);
c1_simulated = n(101:101:101000, 6);
c2_1_simulated = n(101:101:101000, 7);
c2_2_simulated = n(101:101:101000, 8);
re_1_simulated = n(101:101:101000, 10);
re_2_simulated = n(101:101:101000, 11);

set(0, 'defaultfigurecolor', 'w');

L = 100;
porosity_im_j = 0.0;
porosity_m = 0.3;
q_Darcy = 0.5;
v = q_Darcy / porosity_m;
alpha_L = 10.0;
L_c = alpha_L;
t_c = L_c / v;
D = alpha_L * v;
eta = porosity_im_j/porosity_m;

K1 = 10^(-8.6138); % CaCO3(s)
K2 = 10^(-4.1018); % CaSO4(s)

x = 100;
x_D = x/L_c;

t = [0.1:0.1:1000];
t_D = t/t_c;

u = 1.0;

um_D = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s)), t_D);
dum_dx_D = euler_inversion(@(s)  u ./s * exp(x_D/2) .* exp(-x_D/2*sqrt(1+4*s))  .* (1/2) .* ( 1 - sqrt(1+4*s) ) , t_D); 

c1m_D = ( um_D + sqrt(um_D.^2 + 4*(K1+K2)) ) / 2; 
c2m_1_D = 2 * K1 ./ ( um_D + sqrt(um_D.^2 + 4*(K1+K2)) ); 
c2m_2_D = 2 * K2 ./ ( um_D + sqrt(um_D.^2 + 4*(K1+K2)) ); 
dc2m_1_dum_D = - c2m_1_D ./ sqrt(um_D.^2 + 4*(K1+K2)); 
dc2m_2_dum_D = - c2m_2_D ./ sqrt(um_D.^2 + 4*(K1+K2)); 

% ========================= Analytical Solution =========================

% ------------------------- r_mixing ------------------------- 
ddc2m_1_ddum_D = 2*K1./(um_D.^2+4*(K1+K2)).^(3/2);
ddc2m_2_ddum_D = 2*K2./(um_D.^2+4*(K1+K2)).^(3/2);
re_1_m_mixing_D = - ddc2m_1_ddum_D .* dum_dx_D .* dum_dx_D; 
re_2_m_mixing_D = - ddc2m_2_ddum_D .* dum_dx_D .* dum_dx_D; 
re_1_m_mixing = re_1_m_mixing_D / t_c;
re_2_m_mixing = re_2_m_mixing_D / t_c;

figure; 
semilogx(t, um_D, 'Linewidth', 4); 
hold on; 
semilogx(t(10:10:10000), u_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('u_{m} (analytical)', 'u_{m} (numerical)');
xlabel('t');
ylabel('u');

figure; 
semilogx(t, c1m_D, 'Linewidth', 4); 
hold on; 
semilogx(t(10:10:10000), c1_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('c (analytical)', 'c (numerical)');
xlabel('t');
ylabel('[Ca^{2+}]');

figure; 
semilogx(t, c2m_1_D, 'Linewidth', 4); 
hold on; 
semilogx(t(10:10:10000), c2_1_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('c (analytical)', 'c (numerical)');
xlabel('t');
ylabel('[CO_{3}^{2-}]');

figure; 
semilogx(t, c2m_2_D, 'Linewidth', 4); 
hold on; 
semilogx(t(10:10:10000), c2_2_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
legend('c (analytical)', 'c (numerical)');
xlabel('t');
ylabel('[SO_{4}^{2-}]');

figure; 
semilogx(t, re_1_m_mixing, 'Linewidth', 4); 
hold on; 
semilogx(t(10:10:10000), re_1_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e}_{m} (analytical)', 'r_{e}_{m} (numerical)');
xlabel('t');
ylabel('re_{calcite}'); 

figure; 
semilogx(t, re_2_m_mixing, 'Linewidth', 4); 
hold on; 
semilogx(t(10:10:10000), re_2_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e}_{m} (analytical)', 'r_{e}_{m} (numerical)');
xlabel('t');
ylabel('re_{gypsum}');
