n = importdata('output_nodal_variables_vs_x.dat');
e = importdata('output_element_materials_vs_x.dat');
T_simulated = n(101:201:201000, 5)';
um_simulated = n(101:201:201000, 9)';
c1m_simulated = n(101:201:201000, 6)';
c2_1_m_simulated = n(101:201:201000, 7)';
c2_2_m_simulated = n(101:201:201000, 8)';
re_1_m_simulated = n(101:201:201000, 10)';
re_2_m_simulated = n(101:201:201000, 11)';

set(0, 'defaultfigurecolor', 'w');

porosity_m = 0.5;
porosity_im = 0.3;
q_Darcy = 0.5; % m / day
v = q_Darcy / porosity_m;
alpha_L = 1.0;
D = alpha_L * v;

x = 100; % m
t = [1:1000]; % day

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T0 = 298.15;
dT_BC = -25.0;
u_BC = -0.0323301582122000;
u0 = 0.0000106837004;

lambda_w = 0.6 * 86400; % J / day / m / K
lambda_s = 3.2 * 86400; % J / day / m / K
density_w = 1000;
heat_capacity_w = 4200;
density_s = 2700;
heat_capacity_s = 2000;
v_T = ( density_w * heat_capacity_w ) / ( ( porosity_m + porosity_im ) * density_w * heat_capacity_w + (1.0 - porosity_m - porosity_im) * density_s * heat_capacity_s ) * q_Darcy;
D_T = ( ( porosity_m + porosity_im ) * lambda_w + (1.0 - porosity_m - porosity_im) * lambda_s + density_w * heat_capacity_w * D ) / ( ( porosity_m + porosity_im ) * density_w * heat_capacity_w + (1.0 - porosity_m - porosity_im) * density_s * heat_capacity_s );
x1_T = (x-v_T.*t)./sqrt(4.*D_T.*t);
x2_T = (x+v_T.*t)./sqrt(4.*D_T.*t);
dT = dT_BC/2 * ( erfc(x1_T) + exp(v_T.*x./D_T).*erfc(x2_T) );

dT_dt = dT_BC/2 * ( (-2/sqrt(pi)) .* ( exp(-x1_T.^2) .* ( (-1 ./ (2.*t)) .* x2_T ) ) + exp(v_T.*x./D_T) .* (-2/sqrt(pi)) .* ( exp(-x2_T.^2) .* ( (-1 ./ (2.*t)) .* x1_T ) ) );
dT_dx = dT_BC/2 * ( (-2/sqrt(pi)) .* (1./sqrt(4.*D_T.*t)) .* ( exp(-x1_T.^2) + exp(v_T.*x./D_T) .* exp(-x2_T.^2) ) + (v_T/D_T) .* exp(v_T.*x./D_T) .* erfc(x2_T) );
ddT_ddx = dT_BC/2 * ( (-2/sqrt(pi)) .* exp(-x1_T.^2) .* (1./sqrt(4.*D_T.*t)) .* (-2 .* x1_T) .* (1./sqrt(4.*D_T.*t)) ...
                       + (v_T/D_T).^2 .* exp(v_T.*x./D_T) .* erfc(x2_T) + 2 * (v_T/D_T) .* exp(v_T.*x./D_T) .* (-2/sqrt(pi)) .* exp(-x2_T.^2) .* (1./sqrt(4.*D_T.*t)) ...
                       + exp(v_T.*x./D_T) .* (-2/sqrt(pi)) .* exp(-x2_T.^2) .* (1./sqrt(4.*D_T.*t)) .* (-2 .* x2_T) .* (1./sqrt(4.*D_T.*t)) );
R = 8.314;
T_standard = 298.15;
delta_H_standard_1 = (-543.0) + (-675.23) - (-1206.9); % standard enthalpy of reaction CaCO3(s) = Ca2+ + CO3--
delta_H_standard_2 = (-543.0) + (-909.34) - (-1434.1); % standard enthalpy of reaction CaSO4(s) = Ca2+ + SO4--
delta_S_standard_1 = (-53.1) + (-56.9) - (92.9); % standard entropy of reaction CaCO3(s) = Ca2+ + CO3--
delta_S_standard_2 = (-53.1) + (20.1) - (106.7); % standard entropy of reaction CaSO4(s) = Ca2+ + SO4--
delta_G_standard_1 = delta_H_standard_1 * 1000.0 - T_standard .* delta_S_standard_1;
delta_G_standard_2 = delta_H_standard_2 * 1000.0 - T_standard .* delta_S_standard_2;

K1 = exp( - delta_G_standard_1 ./ ( R .* ( T0 + dT ) ) ); % CaCO3(s)
K2 = exp( - delta_G_standard_2 ./ ( R .* ( T0 + dT ) ) ); % CaSO4(s)

dK1_dT = ( delta_G_standard_1 ./ ( R .* ( T0 + dT ).^2 ) ) .* exp( - delta_G_standard_1 ./ ( R .* ( T0 + dT ) ) );
dK2_dT = ( delta_G_standard_2 ./ ( R .* ( T0 + dT ).^2 ) ) .* exp( - delta_G_standard_2 ./ ( R .* ( T0 + dT ) ) );

ddK1_ddT = ( -2*delta_G_standard_1 ./ ( R .* ( T0 + dT ).^3 ) + ( delta_G_standard_1 ./ ( R .* ( T0 + dT ).^2 ) ).^2 ) .* exp( - delta_G_standard_1 ./ ( R .* ( T0 + dT ) ) );
ddK2_ddT = ( -2*delta_G_standard_2 ./ ( R .* ( T0 + dT ).^3 ) + ( delta_G_standard_2 ./ ( R .* ( T0 + dT ).^2 ) ).^2 ) .* exp( - delta_G_standard_2 ./ ( R .* ( T0 + dT ) ) );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('alpha_j.mat');
load('p_j.mat');

um = euler_inversion(@(s)  ( u_BC ./ s ) .* exp( ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) * x ), t);

dum_dx = euler_inversion(@(s)  ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) ...
                        .* ( u_BC ./ s ) .* exp( ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) * x ), t);

ddum_ddx = euler_inversion(@(s)  ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ).^2 ...
                        .* ( u_BC ./ s ) .* exp( ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) * x ), t);

dum_dt = euler_inversion(@(s)  s .* ( u_BC ./ s ) .* exp( ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) * x ), t);

uim_j = zeros(size(alpha_j, 2), size(t, 2));
duim_j_dt = zeros(size(alpha_j, 2), size(t, 2));
for j = 1:size(alpha_j, 2)
    j
    uim_j(j, :) = u0 .* exp(-alpha_j(j).*t') ...
                        + euler_inversion(@(s)  (alpha_j(j)./(s+alpha_j(j))) ...
                        .* ( u_BC ./ s ) .* exp( ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) * x ), t);
    duim_j_dt(j, :) = u0 .* (-alpha_j(j)) .* exp(-alpha_j(j).*t') ...
                        + alpha_j(j) .* um ...
                        + euler_inversion(@(s)  (-alpha_j(j)^2./(s+alpha_j(j))) ...
                        .* ( u_BC ./ s ) .* exp( ( ( q_Darcy - sqrt( q_Darcy^2 + 4*porosity_m*D*( porosity_im .* sum(alpha_j.*p_j./(s+alpha_j)) + porosity_m ) .* s ) ) ./ (2*porosity_m*D) ) * x ), t);
end
uim = zeros(1, size(t, 2));
for j = 1:5
    uim = uim + uim_j(j, :) .* p_j(j);
end

um = um';
dum_dx = dum_dx';
ddum_ddx = ddum_ddx';
dum_dt = dum_dt';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

c1m = ( um + sqrt(um.^2 + 4*(K1+K2)) ) ./ 2;
c2_1_m = ( 2 * K1 ) ./ ( um + sqrt(um.^2 + 4*(K1+K2)) );
c2_2_m = ( 2 * K2 ) ./ ( um + sqrt(um.^2 + 4*(K1+K2)) );

dc2_1_m_dum = - c2_1_m ./ sqrt(um.^2 + 4*(K1+K2));
dc2_2_m_dum = - c2_2_m ./ sqrt(um.^2 + 4*(K1+K2));

dc2_1_m_dK1 = 2 ./ (um + sqrt(um.^2 + 4*(K1+K2))) - 2 .* c2_1_m ./ ( (um + sqrt(um.^2 + 4*(K1+K2))) .* sqrt(um.^2 + 4*(K1+K2)) );
dc2_1_m_dK2 = - 2 .* c2_1_m ./ ( (um + sqrt(um.^2 + 4*(K1+K2))) .* sqrt(um.^2 + 4*(K1+K2)) );
dc2_2_m_dK1 = - 2 .* c2_2_m ./ ( (um + sqrt(um.^2 + 4*(K1+K2))) .* sqrt(um.^2 + 4*(K1+K2)) );
dc2_2_m_dK2 = 2 ./ (um + sqrt(um.^2 + 4*(K1+K2))) - 2 .* c2_2_m ./ ( (um + sqrt(um.^2 + 4*(K1+K2))) .* sqrt(um.^2 + 4*(K1+K2)) );

ddc2_1_m_ddum = ( 2 * K1 ) ./ ( um.^2 + 4*(K1+K2) ).^(3/2);
ddc2_2_m_ddum = ( 2 * K2 ) ./ ( um.^2 + 4*(K1+K2) ).^(3/2);

ddc2_1_m_dumdT = ( -2 ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* sqrt(um.^2 + 4*(K1+K2)) ) + 2.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)) ) + 2.*c2_1_m ./ (um.^2 + 4*(K1+K2)).^(3/2) ) .* dK1_dT ...
            + ( 4.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)) ) + 2.*c2_1_m.*um ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ).* dK2_dT;
ddc2_2_m_dumdT = ( 4.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)) ) + 2.*c2_2_m.*um ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ).* dK1_dT ...
            + ( -2 ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* sqrt(um.^2 + 4*(K1+K2)) ) + 2.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)) ) + 2.*c2_2_m ./ (um.^2 + 4*(K1+K2)).^(3/2) ) .* dK2_dT;

ddc2_1_m_ddT = ( -8 ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* sqrt(um.^2 + 4*(K1+K2)) ) + 8.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* (um.^2 + 4*(K1+K2)) ) + 4.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK1_dT.^2 ...
           + 2 .* ( -4 ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* sqrt(um.^2 + 4*(K1+K2)) ) + 8.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* (um.^2 + 4*(K1+K2)) ) + 4.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ) .* (dK2_dT.*dK1_dT) ...
           + ( 8.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* (um.^2 + 4*(K1+K2)) ) + 4.*c2_1_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK2_dT.^2 ...
           + dc2_1_m_dK1 .* ddK1_ddT ...
           + dc2_1_m_dK2.* ddK2_ddT;
ddc2_2_m_ddT = ( 8.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* (um.^2 + 4*(K1+K2)) ) + 4.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK1_dT.^2 ...
           + 2 .* ( -4 ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* sqrt(um.^2 + 4*(K1+K2)) ) + 8.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* (um.^2 + 4*(K1+K2)) ) + 4.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ) .* (dK2_dT.*dK1_dT) ...
           + ( -8 ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* sqrt(um.^2 + 4*(K1+K2)) ) + 8.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ).^2 .* (um.^2 + 4*(K1+K2)) ) + 4.*c2_2_m ./ ( ( um + sqrt(um.^2 + 4*(K1+K2)) ) .* (um.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK2_dT.^2 ...
           + dc2_2_m_dK1 .* ddK1_ddT ...
           + dc2_2_m_dK2.* ddK2_ddT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

c1_im_j = ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) ./ 2;
c2_1_im_j = ( 2 * K1 ) ./ ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) );
c2_2_im_j = ( 2 * K2 ) ./ ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) );

c1_im = zeros(1, size(t, 2));
c2_1_im = zeros(1, size(t, 2));
c2_2_im = zeros(1, size(t, 2));
for j = 1:5
    c1_im = c1_im + c1_im_j(j, :) .* p_j(j);
    c2_1_im = c2_1_im + c2_1_im_j(j, :) .* p_j(j);
    c2_2_im = c2_2_im + c2_2_im_j(j, :) .* p_j(j);
end

dc2_1_im_j_duim_j = - c2_1_im_j ./ sqrt(uim_j.^2 + 4*(K1+K2));
dc2_2_im_j_duim_j = - c2_2_im_j ./ sqrt(uim_j.^2 + 4*(K1+K2));

dc2_1_im_j_dK1 = 2 ./ (uim_j + sqrt(uim_j.^2 + 4*(K1+K2))) - 2 .* c2_1_im_j ./ ( (uim_j + sqrt(uim_j.^2 + 4*(K1+K2))) .* sqrt(uim_j.^2 + 4*(K1+K2)) );
dc2_1_im_j_dK2 = - 2 .* c2_1_im_j ./ ( (uim_j + sqrt(uim_j.^2 + 4*(K1+K2))) .* sqrt(uim_j.^2 + 4*(K1+K2)) );
dc2_2_im_j_dK1 = - 2 .* c2_2_im_j ./ ( (uim_j + sqrt(uim_j.^2 + 4*(K1+K2))) .* sqrt(uim_j.^2 + 4*(K1+K2)) );
dc2_2_im_j_dK2 = 2 ./ (uim_j + sqrt(uim_j.^2 + 4*(K1+K2))) - 2 .* c2_2_im_j ./ ( (uim_j + sqrt(uim_j.^2 + 4*(K1+K2))) .* sqrt(uim_j.^2 + 4*(K1+K2)) );

ddc2_1_im_j_dduim_j = ( 2 * K1 ) ./ ( uim_j.^2 + 4*(K1+K2) ).^(3/2);
ddc2_2_im_j_dduim_j = ( 2 * K2 ) ./ ( uim_j.^2 + 4*(K1+K2) ).^(3/2);

ddc2_1_im_j_duim_j_dT = ( -2 ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* sqrt(uim_j.^2 + 4*(K1+K2)) ) + 2.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)) ) + 2.*c2_1_im_j ./ (uim_j.^2 + 4*(K1+K2)).^(3/2) ) .* dK1_dT ...
            + ( 4.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)) ) + 2.*c2_1_im_j.*uim_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ).* dK2_dT;
ddc2_2_im_j_duim_j_dT = ( 4.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)) ) + 2.*c2_2_im_j.*uim_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ).* dK1_dT ...
            + ( -2 ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* sqrt(uim_j.^2 + 4*(K1+K2)) ) + 2.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)) ) + 2.*c2_2_im_j ./ (uim_j.^2 + 4*(K1+K2)).^(3/2) ) .* dK2_dT;

ddc2_1_im_j_ddT = ( -8 ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* sqrt(uim_j.^2 + 4*(K1+K2)) ) + 8.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* (uim_j.^2 + 4*(K1+K2)) ) + 4.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK1_dT.^2 ...
           + 2 .* ( -4 ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* sqrt(uim_j.^2 + 4*(K1+K2)) ) + 8.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* (uim_j.^2 + 4*(K1+K2)) ) + 4.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ) .* (dK2_dT.*dK1_dT) ...
           + ( 8.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* (uim_j.^2 + 4*(K1+K2)) ) + 4.*c2_1_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK2_dT.^2 ...
           + dc2_1_im_j_dK1 .* ddK1_ddT ...
           + dc2_1_im_j_dK2.* ddK2_ddT;
ddc2_2_im_j_ddT = ( 8.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* (uim_j.^2 + 4*(K1+K2)) ) + 4.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK1_dT.^2 ...
           + 2 .* ( -4 ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* sqrt(uim_j.^2 + 4*(K1+K2)) ) + 8.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* (uim_j.^2 + 4*(K1+K2)) ) + 4.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ) .* (dK2_dT.*dK1_dT) ...
           + ( -8 ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* sqrt(uim_j.^2 + 4*(K1+K2)) ) + 8.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ).^2 .* (uim_j.^2 + 4*(K1+K2)) ) + 4.*c2_2_im_j ./ ( ( uim_j + sqrt(uim_j.^2 + 4*(K1+K2)) ) .* (uim_j.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK2_dT.^2 ...
           + dc2_2_im_j_dK1 .* ddK1_ddT ...
           + dc2_2_im_j_dK2.* ddK2_ddT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
re_1_im_j = zeros(size(alpha_j, 2), size(t, 2));
re_2_im_j = zeros(size(alpha_j, 2), size(t, 2));
for j = 1:5
    re_1_im_j(j, :) =  ( dc2_1_im_j_duim_j(j, :) .* duim_j_dt(j, :) + dc2_1_im_j_dK1(j, :) .* dK1_dT .* dT_dt + dc2_1_im_j_dK2(j, :) .* dK2_dT .* dT_dt - alpha_j(j) .* ( c2_1_m - c2_1_im_j(j, :) ) );
    re_2_im_j(j, :) =  ( dc2_2_im_j_duim_j(j, :) .* duim_j_dt(j, :) + dc2_2_im_j_dK1(j, :) .* dK1_dT .* dT_dt + dc2_2_im_j_dK2(j, :) .* dK2_dT .* dT_dt - alpha_j(j) .* ( c2_2_m - c2_2_im_j(j, :) ) );
end
re_1_im = zeros(1, size(t, 2));
re_2_im = zeros(1, size(t, 2));
for j = 1:5
    re_1_im = re_1_im + re_1_im_j(j, :) .* p_j(j);
    re_2_im = re_2_im + re_2_im_j(j, :) .* p_j(j);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
re_1_m = zeros(1, size(t, 2));
for j = 1:5
    re_1_m = re_1_m + dc2_1_m_dum .* ( - porosity_im / porosity_m ) .* p_j(j) .* duim_j_dt(j, :);
end
re_1_m = re_1_m + (dc2_1_m_dK1 .* dK1_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) + (dc2_1_m_dK2 .* dK2_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) ...
                - ddc2_1_m_ddum .* dum_dx .* D .* dum_dx - 2 .* ddc2_1_m_dumdT .* dum_dx .* D .* dT_dx - ddc2_1_m_ddT .* dT_dx .* D .* dT_dx; 
for j = 1:5
    re_1_m = re_1_m + ( porosity_im / porosity_m ) .* p_j(j) .* ( dc2_1_im_j_duim_j(j, :) .* duim_j_dt(j, :) ...
                                                                + dc2_1_im_j_dK1(j, :) .* dK1_dT .* dT_dt  ...
                                                                + dc2_1_im_j_dK2(j, :) .* dK2_dT .* dT_dt );
end
re_1_m = re_1_m + ( - porosity_im / porosity_m ) .* re_1_im;

re_2_m = zeros(1, size(t, 2));
for j = 1:5
    re_2_m = re_2_m + dc2_2_m_dum .* ( - porosity_im / porosity_m ) .* p_j(j) .* duim_j_dt(j, :);
end
re_2_m = re_2_m + (dc2_2_m_dK1 .* dK1_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) + (dc2_2_m_dK2 .* dK2_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) ...
                - ddc2_2_m_ddum .* dum_dx .* D .* dum_dx - 2 .* ddc2_2_m_dumdT .* dum_dx .* D .* dT_dx - ddc2_2_m_ddT .* dT_dx .* D .* dT_dx;
for j = 1:5
    re_2_m = re_2_m + ( porosity_im / porosity_m ) .* p_j(j) .* ( dc2_2_im_j_duim_j(j, :) .* duim_j_dt(j, :) ...
                                                                + dc2_2_im_j_dK1(j, :) .* dK1_dT .* dT_dt  ...
                                                                + dc2_2_im_j_dK2(j, :) .* dK2_dT .* dT_dt );
end
re_2_m = re_2_m + ( - porosity_im / porosity_m ) .* re_2_im;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure; 
semilogx(t, T0 + dT, 'Linewidth', 4);
hold on; 
semilogx(t, T_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('T [K]');

figure; 
semilogx(t, um, 'Linewidth', 4); 
hold on; 
semilogx(t, um_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('u');

figure; 
semilogx(t, c1m, 'Linewidth', 4); 
hold on; 
semilogx(t, c1m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('[Ca^{2+}]');

figure; 
semilogx(t, c2_1_m, 'Linewidth', 4); 
hold on; 
semilogx(t, c2_1_m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('[CO_{3}^{2-}]');

figure; 
semilogx(t, c2_2_m, 'Linewidth', 4); 
hold on; 
semilogx(t, c2_2_m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('[SO_{4}^{2-}]');

figure;
semilogx(t, ddc2_1_m_ddum, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,1}/\partialu^{2}']); 

figure;
semilogx(t, ddc2_2_m_ddum, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,2}/\partialu^{2}']); 

figure;
semilogx(t, ddc2_1_m_dumdT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,1}/\partialu\partialT']); 

figure;
semilogx(t, ddc2_2_m_dumdT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,2}/\partialu\partialT']); 

figure;
semilogx(t, ddc2_1_m_ddT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,1}/\partialT^{2}']); 

figure;
semilogx(t, ddc2_2_m_ddT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,2}/\partialT^{2}']); 

% figure;
% semilogx(t, du_dx .* D .* du_dx, 'Linewidth', 4); 
% hold on;
% semilogx(t, du_dx_simulated .* D .* du_dx_simulated, 'Linewidth', 4); 
% xlim([10^(0) 10^(3)]);
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% xlabel('t');
% ylabel('rate of mixing'); 
% 
% figure;
% semilogx(t, du_dx .* D .* dT_dx, 'Linewidth', 4); 
% hold on;
% semilogx(t, du_dx_simulated .* D .* dT_dx_simulated, 'Linewidth', 4); 
% xlim([10^(0) 10^(3)]);
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% xlabel('t');
% ylabel('rate of mixing'); 
% 
% figure;
% semilogx(t, dT_dx .* D .* dT_dx, 'Linewidth', 4); 
% hold on;
% semilogx(t, dT_dx_simulated .* D .* dT_dx_simulated, 'Linewidth', 4); 
% xlim([10^(0) 10^(3)]);
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% xlabel('t');
% ylabel('rate of mixing'); 

figure; 
semilogx(t, re_1_m, 'Linewidth', 4); 
hold on;
semilogx(t, re_1_m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e} (analytical) T_{BC} = 273.15 K', 'r_{e} (numerical) T_{BC} = 273.15 K');
xlabel('t');
ylabel('re_{1}_{m}'); 

figure; 
semilogx(t, re_2_m, 'Linewidth', 4); 
hold on;
semilogx(t, re_2_m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e} (analytical) T_{BC} = 273.15 K', 'r_{e} (numerical) T_{BC} = 273.15 K');
xlabel('t');
ylabel('re_{2}_{m}');

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_im_j_simulated = importdata('output_nodal_variables_u_im_j_vs_x.dat');
% u_im_simulated = zeros(size(u_im_j_simulated, 1), 1);
% for j = 1:5
%     u_im_simulated = u_im_simulated + u_im_j_simulated(:, j) .* p_j(j);
% end
% 
% figure; 
% semilogx(t, uim, 'Linewidth', 4); 
% hold on;
% semilogx(t, u_im_simulated(101:201:201000, 1), 'o', 'Linewidth', 4); 
% semilogx(t, uim_j, 'Linewidth', 4); 
% semilogx(t, u_im_j_simulated(101:201:201000, 1), ':', 'Linewidth', 4); 
% semilogx(t, u_im_j_simulated(101:201:201000, 2), ':', 'Linewidth', 4); 
% semilogx(t, u_im_j_simulated(101:201:201000, 3), ':', 'Linewidth', 4); 
% semilogx(t, u_im_j_simulated(101:201:201000, 4), ':', 'Linewidth', 4); 
% semilogx(t, u_im_j_simulated(101:201:201000, 5), ':', 'Linewidth', 4); 
% xlim([10^(0) 10^(3)])
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% legend('u_{im} (analytical) T_{BC} = 273.15 K', 'u_{im} (numerical) T_{BC} = 273.15 K');
% xlabel('t');
% ylabel('u_{im}'); 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% c_im_j_simulated = importdata('output_nodal_variables_c_im_j_vs_x.dat');
% c1_im_simulated = zeros(size(c_im_j_simulated, 1), 1);
% c2_1_im_simulated = zeros(size(c_im_j_simulated, 1), 1);
% c2_2_im_simulated = zeros(size(c_im_j_simulated, 1), 1);
% for j = 1:5
%     c1_im_simulated = c1_im_simulated + c_im_j_simulated(:, (j-1)*3+1) .* p_j(j);
%     c2_1_im_simulated = c2_1_im_simulated + c_im_j_simulated(:, (j-1)*3+2) .* p_j(j);
%     c2_2_im_simulated = c2_2_im_simulated + c_im_j_simulated(:, (j-1)*3+3) .* p_j(j);
% end
% c1_im_j_simulated = c_im_j_simulated(101:201:201000, 1:3:15);
% c2_1_im_j_simulated = c_im_j_simulated(101:201:201000, 2:3:15);
% c2_2_im_j_simulated = c_im_j_simulated(101:201:201000, 3:3:15);
% 
% figure; 
% semilogx(t, c1_im, 'Linewidth', 4); 
% hold on;
% semilogx(t, c1_im_simulated(101:201:201000, 1), 'o', 'Linewidth', 4); 
% semilogx(t, c1_im_j, 'Linewidth', 4); 
% semilogx(t, c1_im_j_simulated(:, 1), ':', 'Linewidth', 4); 
% semilogx(t, c1_im_j_simulated(:, 2), ':', 'Linewidth', 4); 
% semilogx(t, c1_im_j_simulated(:, 3), ':', 'Linewidth', 4); 
% semilogx(t, c1_im_j_simulated(:, 4), ':', 'Linewidth', 4); 
% semilogx(t, c1_im_j_simulated(:, 5), ':', 'Linewidth', 4); 
% xlim([10^(0) 10^(3)])
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% legend('c_{1}_{im} (analytical) T_{BC} = 273.15 K', 'c_{1}_{im} (numerical) T_{BC} = 273.15 K');
% xlabel('t');
% ylabel('c_{1}_{im}'); 
% 
% figure; 
% semilogx(t, c2_1_im, 'Linewidth', 4); 
% hold on;
% semilogx(t, c2_1_im_simulated(101:201:201000, 1), 'o', 'Linewidth', 4); 
% semilogx(t, c2_1_im_j, 'Linewidth', 4); 
% semilogx(t, c2_1_im_j_simulated(:, 1), ':', 'Linewidth', 4); 
% semilogx(t, c2_1_im_j_simulated(:, 2), ':', 'Linewidth', 4); 
% semilogx(t, c2_1_im_j_simulated(:, 3), ':', 'Linewidth', 4); 
% semilogx(t, c2_1_im_j_simulated(:, 4), ':', 'Linewidth', 4); 
% semilogx(t, c2_1_im_j_simulated(:, 5), ':', 'Linewidth', 4); 
% xlim([10^(0) 10^(3)])
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% legend('c_{2,1}_{im} (analytical) T_{BC} = 273.15 K', 'c_{2,1}_{im} (numerical) T_{BC} = 273.15 K');
% xlabel('t');
% ylabel('c_{2,1}_{im}'); 
% 
% figure; 
% semilogx(t, c2_2_im, 'Linewidth', 4); 
% hold on;
% semilogx(t, c2_2_im_simulated(101:201:201000, 1), 'o', 'Linewidth', 4); 
% semilogx(t, c2_2_im_j, 'Linewidth', 4); 
% semilogx(t, c2_2_im_j_simulated(:, 1), ':', 'Linewidth', 4); 
% semilogx(t, c2_2_im_j_simulated(:, 2), ':', 'Linewidth', 4); 
% semilogx(t, c2_2_im_j_simulated(:, 3), ':', 'Linewidth', 4); 
% semilogx(t, c2_2_im_j_simulated(:, 4), ':', 'Linewidth', 4); 
% semilogx(t, c2_2_im_j_simulated(:, 5), ':', 'Linewidth', 4); 
% xlim([10^(0) 10^(3)])
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% legend('c_{2,2}_{im} (analytical) T_{BC} = 273.15 K', 'c_{2,2}_{im} (numerical) T_{BC} = 273.15 K');
% xlabel('t');
% ylabel('c_{2,2}_{im}'); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
re_im_j_simulated = importdata('output_nodal_variables_re_im_j_vs_x.dat');
re_1_im_simulated = zeros(size(re_im_j_simulated, 1), 1);
re_2_im_simulated = zeros(size(re_im_j_simulated, 1), 1);
for j = 1:5
    re_1_im_simulated = re_1_im_simulated + re_im_j_simulated(:, (j-1)*2+1) .* p_j(j);
    re_2_im_simulated = re_2_im_simulated + re_im_j_simulated(:, (j-1)*2+2) .* p_j(j);
end
re_1_im_j_simulated = re_im_j_simulated(101:201:201000, 1:2:10);
re_2_im_j_simulated = re_im_j_simulated(101:201:201000, 2:2:10);

figure; 
semilogx(t, re_1_im, 'Linewidth', 4); 
hold on;
semilogx(t, re_1_im_simulated(101:201:201000, 1), 'o', 'Linewidth', 4); 
semilogx(t, re_1_im_j, 'Linewidth', 4); 
semilogx(t, re_1_im_j_simulated(:, 1), ':', 'Linewidth', 4); 
semilogx(t, re_1_im_j_simulated(:, 2), ':', 'Linewidth', 4); 
semilogx(t, re_1_im_j_simulated(:, 3), ':', 'Linewidth', 4); 
semilogx(t, re_1_im_j_simulated(:, 4), ':', 'Linewidth', 4); 
semilogx(t, re_1_im_j_simulated(:, 5), ':', 'Linewidth', 4); 
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('re_1_{im} (analytical) T_{BC} = 273.15 K', 're_1_{im} (numerical) T_{BC} = 273.15 K');
xlabel('t');
ylabel('re_{1}_{im}'); 

figure; 
semilogx(t, re_2_im, 'Linewidth', 4); 
hold on;
semilogx(t, re_2_im_simulated(101:201:201000, 1), 'o', 'Linewidth', 4); 
semilogx(t, re_2_im_j, 'Linewidth', 4); 
semilogx(t, re_2_im_j_simulated(:, 1), ':', 'Linewidth', 4); 
semilogx(t, re_2_im_j_simulated(:, 2), ':', 'Linewidth', 4); 
semilogx(t, re_2_im_j_simulated(:, 3), ':', 'Linewidth', 4); 
semilogx(t, re_2_im_j_simulated(:, 4), ':', 'Linewidth', 4); 
semilogx(t, re_2_im_j_simulated(:, 5), ':', 'Linewidth', 4); 
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('re_2_{im} (analytical) T_{BC} = 273.15 K', 're_2_{im} (numerical) T_{BC} = 273.15 K');
xlabel('t');
ylabel('re_{2}_{im}'); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure; 
semilogx(t, re_1_m, 'Linewidth', 4); 
hold on;
semilogx(t, re_1_m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
semilogx(t, re_1_im, 'Linewidth', 4); 
semilogx(t, re_1_im_simulated(101:201:201000, 1), 'o', 'markersize', 10, 'Linewidth', 3); 
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e}_{m} (analytical)', 'r_{e}_{m} (numerical)', 'r_{e}_{im} (analytical)', 'r_{e}_{im} (numerical)');
xlabel('t');
ylabel('re_{1}'); 

figure; 
semilogx(t, re_2_m, 'Linewidth', 4); 
hold on;
semilogx(t, re_2_m_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
semilogx(t, re_2_im, 'Linewidth', 4); 
semilogx(t, re_2_im_simulated(101:201:201000, 1), 'o', 'markersize', 10, 'Linewidth', 3); 
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e}_{m} (analytical)', 'r_{e}_{m} (numerical)', 'r_{e}_{im} (analytical)', 'r_{e}_{im} (numerical)');
xlabel('t');
ylabel('re_{2}');
