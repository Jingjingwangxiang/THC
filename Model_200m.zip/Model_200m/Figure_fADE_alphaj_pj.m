%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
slope = [0.5 0.5 0.5 0.5 0.5]; 
t1 = [10 10 10 0.01 0.1];
tn = [1000 10000 100000 100 100];
delta_log = ( log10(tn) - log10(t1) ) ./ 4;
fac = 10.^(delta_log);
tau_alpha_j = zeros(size(tn, 2), 5);
for i = 1:size(tn, 2)
    step = [log10(t1(i)) : delta_log(i) : log10(tn(i))];
    tau_alpha_j(i, :) = 10.^step;
end
alpha_j = 1./tau_alpha_j;

p_j = zeros(size(tn, 2), size(tau_alpha_j, 2));
p_j(:, size(tau_alpha_j, 2)) = 1.0;
for i = 1:size(tn, 2)
    for j = size(tau_alpha_j, 2)-1 : -1 : 1
        p_j(i, j) = (sum(p_j(i, j+1:size(tau_alpha_j, 2)).*alpha_j(i, j+1:size(tau_alpha_j, 2)))./alpha_j(i, j)).*((alpha_j(i, j)/alpha_j(i, j+1)).^slope(i) - 1.0);
    end
    p_j(i, :) = p_j(i, :) / sum(p_j(i, :));
end

sum(alpha_j.*p_j)

figure; 
for i = 1:size(tn, 2)
    loglog(alpha_j(i, :), p_j(i, :), 'linewidth', 4);
    hold on; 
end
set(gca, 'Fontweight', 'bold', 'Fontsize', 14);
xlabel('\alpha_{j}');
ylabel('p_{j}');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t = [1:10:1.0e+6];
gt = zeros(size(tn, 2), size(t, 2));
for i = 1:size(tn, 2)
    for j = 1:size(t, 2)
        gt(i, j) = sum(alpha_j(i, :).*p_j(i, :).*exp(-alpha_j(i, :).*t(j)));
    end
end

figure;
for i = 1:size(tn, 2)
    loglog(t, gt(i, :), 'linewidth', 4);
    hold on;
end
set(gca, 'Fontweight', 'bold', 'Fontsize', 14);
ylim([1.0e-08 1.0]);
xlabel('t');
ylabel('g(t)');