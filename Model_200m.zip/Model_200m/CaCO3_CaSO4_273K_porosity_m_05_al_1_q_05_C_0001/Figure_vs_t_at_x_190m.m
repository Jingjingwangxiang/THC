n = importdata('output_nodal_variables_vs_x.dat');
e = importdata('output_element_materials_vs_x.dat');
T_simulated = n(191:201:201000, 5)';
u_simulated = n(191:201:201000, 9)';
c1_simulated = n(191:201:201000, 6)';
c2_1_simulated = n(191:201:201000, 7)';
c2_2_simulated = n(191:201:201000, 8)';
re_1_simulated = n(191:201:201000, 10)';
re_2_simulated = n(191:201:201000, 11)';
Tre_simulated = n(191:201:201000, 12)';

set(0, 'defaultfigurecolor', 'w');

porosity_m = 0.5;
q_Darcy = 0.5;
v = q_Darcy / porosity_m;
alpha_L = 1.0;
D = alpha_L * v;

x = 190;
t = [1:1000];

T0 = 298.15;
dT_BC = -25.0;
u_BC = -0.0323301582122000;

lambda_w = 0.6; 
lambda_s = 3.2;
density_w = 1000;
heat_capacity_w = 4200;
density_s = 2700;
heat_capacity_s = 2000;
v_T = ( density_w * heat_capacity_w ) / ( porosity_m * density_w * heat_capacity_w + (1.0 - porosity_m) * density_s * heat_capacity_s ) * q_Darcy;
D_T = ( porosity_m * lambda_w + (1.0 - porosity_m) * lambda_s + density_w * heat_capacity_w * D ) / ( porosity_m * density_w * heat_capacity_w + (1.0 - porosity_m) * density_s * heat_capacity_s );
x1_T = (x-v_T.*t)./sqrt(4.*D_T.*t);
x2_T = (x+v_T.*t)./sqrt(4.*D_T.*t);
dT = dT_BC/2 * ( erfc(x1_T) + exp(v_T.*x./D_T).*erfc(x2_T) );

dT_dt = dT_BC/2 * ( (-2/sqrt(pi)) .* ( exp(-x1_T.^2) .* ( (-1 ./ (2.*t)) .* x2_T ) ) + exp(v_T.*x./D_T) .* (-2/sqrt(pi)) .* ( exp(-x2_T.^2) .* ( (-1 ./ (2.*t)) .* x1_T ) ) );
dT_dx = dT_BC/2 * ( (-2/sqrt(pi)) .* (1./sqrt(4.*D_T.*t)) .* ( exp(-x1_T.^2) + exp(v_T.*x./D_T) .* exp(-x2_T.^2) ) + (v_T/D_T) .* exp(v_T.*x./D_T) .* erfc(x2_T) );
ddT_ddx = dT_BC/2 * ( (-2/sqrt(pi)) .* exp(-x1_T.^2) .* (1./sqrt(4.*D_T.*t)) .* (-2 .* x1_T) .* (1./sqrt(4.*D_T.*t)) ...
                       + (v_T/D_T).^2 .* exp(v_T.*x./D_T) .* erfc(x2_T) + 2 * (v_T/D_T) .* exp(v_T.*x./D_T) .* (-2/sqrt(pi)) .* exp(-x2_T.^2) .* (1./sqrt(4.*D_T.*t)) ...
                       + exp(v_T.*x./D_T) .* (-2/sqrt(pi)) .* exp(-x2_T.^2) .* (1./sqrt(4.*D_T.*t)) .* (-2 .* x2_T) .* (1./sqrt(4.*D_T.*t)) );
R = 8.314;
T_standard = 298.15;
delta_H_standard_1 = (-543.0) + (-675.23) - (-1206.9); % standard enthalpy of reaction CaCO3(s) = Ca2+ + CO3--
delta_H_standard_2 = (-543.0) + (-909.34) - (-1434.1); % standard enthalpy of reaction CaSO4(s) = Ca2+ + SO4--
delta_S_standard_1 = (-53.1) + (-56.9) - (92.9); % standard entropy of reaction CaCO3(s) = Ca2+ + CO3--
delta_S_standard_2 = (-53.1) + (20.1) - (106.7); % standard entropy of reaction CaSO4(s) = Ca2+ + SO4--
delta_G_standard_1 = delta_H_standard_1 * 1000.0 - T_standard .* delta_S_standard_1;
delta_G_standard_2 = delta_H_standard_2 * 1000.0 - T_standard .* delta_S_standard_2;

K1 = exp( - delta_G_standard_1 ./ ( R .* ( T0 + dT ) ) ); % CaCO3(s)
K2 = exp( - delta_G_standard_2 ./ ( R .* ( T0 + dT ) ) ); % CaSO4(s)

dK1_dT = ( delta_G_standard_1 ./ ( R .* ( T0 + dT ).^2 ) ) .* exp( - delta_G_standard_1 ./ ( R .* ( T0 + dT ) ) );
dK2_dT = ( delta_G_standard_2 ./ ( R .* ( T0 + dT ).^2 ) ) .* exp( - delta_G_standard_2 ./ ( R .* ( T0 + dT ) ) );

ddK1_ddT = ( -2*delta_G_standard_1 ./ ( R .* ( T0 + dT ).^3 ) + ( delta_G_standard_1 ./ ( R .* ( T0 + dT ).^2 ) ).^2 ) .* exp( - delta_G_standard_1 ./ ( R .* ( T0 + dT ) ) );
ddK2_ddT = ( -2*delta_G_standard_2 ./ ( R .* ( T0 + dT ).^3 ) + ( delta_G_standard_2 ./ ( R .* ( T0 + dT ).^2 ) ).^2 ) .* exp( - delta_G_standard_2 ./ ( R .* ( T0 + dT ) ) );

x1 = (x-v.*t)./sqrt(4.*D.*t);
x2 = (x+v.*t)./sqrt(4.*D.*t);
u = u_BC/2 * ( erfc(x1) + exp(v.*x./D).*erfc(x2) );

du_dx = u_BC/2 * ( (-2/sqrt(pi)) .* (1./sqrt(4.*D.*t)) .* ( exp(-x1.^2) + exp(v.*x./D) .* exp(-x2.^2) ) + (v/D) .* exp(v.*x./D) .* erfc(x2) );

c1 = ( u + sqrt(u.^2 + 4*(K1+K2)) ) ./ 2;
c2_1 = ( 2 * K1 ) ./ ( u + sqrt(u.^2 + 4*(K1+K2)) );
c2_2 = ( 2 * K2 ) ./ ( u + sqrt(u.^2 + 4*(K1+K2)) );

dc2_1_du = - c2_1 ./ sqrt(u.^2 + 4*(K1+K2));
dc2_2_du = - c2_2 ./ sqrt(u.^2 + 4*(K1+K2));

dc2_1_dK1 = 2 ./ (u + sqrt(u.^2 + 4*(K1+K2))) - 2 .* c2_1 ./ ( (u + sqrt(u.^2 + 4*(K1+K2))) .* sqrt(u.^2 + 4*(K1+K2)) );
dc2_1_dK2 = - 2 .* c2_1 ./ ( (u + sqrt(u.^2 + 4*(K1+K2))) .* sqrt(u.^2 + 4*(K1+K2)) );
dc2_2_dK1 = - 2 .* c2_2 ./ ( (u + sqrt(u.^2 + 4*(K1+K2))) .* sqrt(u.^2 + 4*(K1+K2)) );
dc2_2_dK2 = 2 ./ (u + sqrt(u.^2 + 4*(K1+K2))) - 2 .* c2_2 ./ ( (u + sqrt(u.^2 + 4*(K1+K2))) .* sqrt(u.^2 + 4*(K1+K2)) );

ddc2_1_ddu = ( 2 * K1 ) ./ ( u.^2 + 4*(K1+K2) ).^(3/2);
ddc2_2_ddu = ( 2 * K2 ) ./ ( u.^2 + 4*(K1+K2) ).^(3/2);

ddc2_1_dudT = ( -2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* sqrt(u.^2 + 4*(K1+K2)) ) + 2.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)) ) + 2.*c2_1 ./ (u.^2 + 4*(K1+K2)).^(3/2) ) .* dK1_dT ...
            + ( 4.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)) ) + 2.*c2_1.*u ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ).* dK2_dT;
ddc2_2_dudT = ( 4.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)) ) + 2.*c2_2.*u ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ).* dK1_dT ...
            + ( -2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* sqrt(u.^2 + 4*(K1+K2)) ) + 2.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)) ) + 2.*c2_2 ./ (u.^2 + 4*(K1+K2)).^(3/2) ) .* dK2_dT;

ddc2_1_ddT = ( -8 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* sqrt(u.^2 + 4*(K1+K2)) ) + 8.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* (u.^2 + 4*(K1+K2)) ) + 4.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK1_dT.^2 ...
           + 2 .* ( -4 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* sqrt(u.^2 + 4*(K1+K2)) ) + 8.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* (u.^2 + 4*(K1+K2)) ) + 4.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ) .* (dK2_dT.*dK1_dT) ...
           + ( 8.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* (u.^2 + 4*(K1+K2)) ) + 4.*c2_1 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK2_dT.^2 ...
           + dc2_1_dK1 .* ddK1_ddT ...
           + dc2_1_dK2.* ddK2_ddT;
ddc2_2_ddT = ( 8.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* (u.^2 + 4*(K1+K2)) ) + 4.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK1_dT.^2 ...
           + 2 .* ( -4 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* sqrt(u.^2 + 4*(K1+K2)) ) + 8.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* (u.^2 + 4*(K1+K2)) ) + 4.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ) .* (dK2_dT.*dK1_dT) ...
           + ( -8 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* sqrt(u.^2 + 4*(K1+K2)) ) + 8.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ).^2 .* (u.^2 + 4*(K1+K2)) ) + 4.*c2_2 ./ ( ( u + sqrt(u.^2 + 4*(K1+K2)) ) .* (u.^2 + 4*(K1+K2)).^(3/2) ) ) .* dK2_dT.^2 ...
           + dc2_2_dK1 .* ddK1_ddT ...
           + dc2_2_dK2.* ddK2_ddT;

re_1_analytical =  (dc2_1_dK1 .* dK1_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) + (dc2_1_dK2 .* dK2_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) ...
                - ddc2_1_ddu .* du_dx .* D .* du_dx - 2 .* ddc2_1_dudT .* du_dx .* D .* dT_dx - ddc2_1_ddT .* dT_dx .* D .* dT_dx; 
re_2_analytical =  (dc2_2_dK1 .* dK1_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) + (dc2_2_dK2 .* dK2_dT .* (dT_dt - (-v .* dT_dx + D .* ddT_ddx))) ...
                - ddc2_2_ddu .* du_dx .* D .* du_dx - 2 .* ddc2_2_dudT .* du_dx .* D .* dT_dx - ddc2_2_ddT .* dT_dx .* D .* dT_dx;

figure; 
semilogx(t, T0 + dT, 'Linewidth', 4);
hold on; 
semilogx(t, T_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('T [K]');

figure; 
semilogx(t, u, 'Linewidth', 4); 
hold on; 
semilogx(t, u_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('u');

figure; 
semilogx(t, c1, 'Linewidth', 4); 
hold on; 
semilogx(t, c1_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('[Ca^{2+}]');

figure; 
semilogx(t, c2_1, 'Linewidth', 4); 
hold on; 
semilogx(t, c2_1_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('[CO_{3}^{2-}]');

figure; 
semilogx(t, c2_2, 'Linewidth', 4); 
hold on; 
semilogx(t, c2_2_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 1, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('[SO_{4}^{2-}]');

figure;
semilogx(t, ddc2_1_ddu, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,1}/\partialu^{2}']); 

figure;
semilogx(t, ddc2_2_ddu, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,2}/\partialu^{2}']); 

figure;
semilogx(t, ddc2_1_dudT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,1}/\partialu\partialT']); 

figure;
semilogx(t, ddc2_2_dudT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,2}/\partialu\partialT']); 

figure;
semilogx(t, ddc2_1_ddT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,1}/\partialT^{2}']); 

figure;
semilogx(t, ddc2_2_ddT, 'Linewidth', 4); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel(['\partial^{2}c_{2,2}/\partialT^{2}']); 

figure;
semilogx(t, dT_dx, 'Linewidth', 4); 
hold on;
semilogx(t, dT_dx_simulated, 'o', 'markersize', 10, 'Linewidth', 3); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('dTdx'); 

figure;
semilogx(t, du_dx, 'Linewidth', 4); 
hold on;
semilogx(t, du_dx_simulated, 'o', 'markersize', 10, 'Linewidth', 3); 
xlim([10^(0) 10^(3)]);
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('dudx'); 

% figure;
% semilogx(t, du_dx .* D .* du_dx, 'Linewidth', 4); 
% hold on;
% semilogx(t, du_dx_simulated .* D .* du_dx_simulated, 'Linewidth', 4); 
% xlim([10^(0) 10^(3)]);
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% xlabel('t');
% ylabel('rate of mixing'); 
% 
% figure;
% semilogx(t, du_dx .* D .* dT_dx, 'Linewidth', 4); 
% hold on;
% semilogx(t, du_dx_simulated .* D .* dT_dx_simulated, 'Linewidth', 4); 
% xlim([10^(0) 10^(3)]);
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% xlabel('t');
% ylabel('rate of mixing'); 
% 
% figure;
% semilogx(t, dT_dx .* D .* dT_dx, 'Linewidth', 4); 
% hold on;
% semilogx(t, dT_dx_simulated .* D .* dT_dx_simulated, 'Linewidth', 4); 
% xlim([10^(0) 10^(3)]);
% set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
% xlabel('t');
% ylabel('rate of mixing'); 

figure; 
semilogx(t, (dT_dt - (-v .* dT_dx + D .* ddT_ddx)), 'Linewidth', 4);
hold on;
semilogx(t, Tre_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
xlabel('t');
ylabel('Tre'); 

figure; 
semilogx(t, re_1_analytical, 'Linewidth', 4); 
hold on;
semilogx(t, re_1_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e} (analytical) T_{BC} = 273.15 K', 'r_{e} (numerical) T_{BC} = 273.15 K');
xlabel('t');
ylabel('re_{calcite}'); 

figure; 
semilogx(t, re_2_analytical, 'Linewidth', 4); 
hold on;
semilogx(t, re_2_simulated, 'o', 'markersize', 10, 'Linewidth', 3);
xlim([10^(0) 10^(3)])
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 28);
legend('r_{e} (analytical) T_{BC} = 273.15 K', 'r_{e} (numerical) T_{BC} = 273.15 K');
xlabel('t');
ylabel('re_{gypsum}');
