
load('T.mat');
load('u.mat');
t = [1:1000];

set(0, 'defaultfigurecolor', 'w');

figure;

yyaxis left
plot(t, u);
xlabel('t');
ylabel('u');
legend('\DeltaT = -25 K', '\DeltaT = 0 K', '\DeltaT = 25 K');

yyaxis right
plot(t, T);
ylabel('T');
legend('\DeltaT = -25 K', '\DeltaT = 0 K', '\DeltaT = 25 K');

load('T_vs_x.mat');
load('u_vs_x.mat');
x = [0:100];

set(0, 'defaultfigurecolor', 'w');

figure;

yyaxis left
plot(x, u_vs_x);
xlabel('x');
ylabel('c');

yyaxis right
plot(x, T_vs_x);
ylabel('T');
