set(0, 'defaultfigurecolor', 'w');

P = 365;
dt = P / 120;
t = [0:dt:P];

a_e = zeros(1, 20);
a_e(1) = 0.0;
a_e(2) = 0.4;
for i = 3:20
    a_e(i) = 1.2 * a_e(i-1);
end
Keff_K = zeros(1, 20);
for i = 1:20
    Keff_K(i) = sum ( exp( - a_e(i) * sin(2*pi*t/P) ) * dt ) / P;
end

figure;
semilogy(a_e, Keff_K, 'linewidth', 6);
hold on;
semilogy( a_e(1:11), 1.0 + 0.25 * a_e(1:11).^2, ':', 'linewidth', 5);
semilogy( a_e(12:end), 10.^( 0.4 * a_e(12:end) - 0.58 ), 'o', 'markersize', 18, 'linewidth', 5);
legend('$F(a_{e})$', '$1.0 + 0.25 a_{e}^{2}$', '$10^{0.4 a_{e} - 0.58}$', 'interpreter', 'latex', 'location', 'northwest');
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 32, 'TickLabelInterpreter', 'latex');
xlabel('$a_{e}$', 'Interpreter', 'latex');
ylabel('$F(a_{e}) = K_{eff}/K(\overline{T}) = k_{eff}/k(\overline{T})$', 'interpreter', 'latex');
xlim([0 9]);