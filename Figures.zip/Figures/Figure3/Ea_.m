function [Ea] = Ea_(T)

    Eb = 36500.0; % J / mol / K
    E_delta_H = 59000.0; % J / mol / K
    E_delta_Cp = 2000.0; % J / mol / K
    Tm = 66 + 273.15;  % K
    
    Ea = Eb - E_delta_H * ( 1.0 - T / Tm ) - E_delta_Cp * ( T - Tm - T .* log( T / Tm) ); % J / mol / K

end