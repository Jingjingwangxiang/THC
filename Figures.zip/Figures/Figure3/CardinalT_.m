function [CardinalT] = CardinalT_(T, Tref)
    
    Topt = 55 + 273.15;
    Tmin = 5 + 273.15;
    Tmax = 64 + 273.15;
    for i = 1:size(T, 2)
        if T(i) >= Tmin & T(i) <= Tmax
            bb = ( Tref - Tmax ) .* ( Tref - Tmin ).^2 ./ ( ( Topt - Tmin ) * ( ( Topt - Tmin ) * ( Tref - Topt )  - ( Topt - Tmax ) * ( Topt + Tmin - 2 * Tref ) ) );
            CardinalT(i) = ( T(i) - Tmax ) .* ( T(i) - Tmin ).^2 ./ ( ( Topt - Tmin ) * ( ( Topt - Tmin ) * ( T(i) - Topt )  - ( Topt - Tmax ) * ( Topt + Tmin - 2 * T(i) ) ) ) / bb;
        else
            CardinalT(i) = 0.0;
        end
    end

end