function [EAAR] = EAAR_(T, Tref)
    
    Ea_T = Ea_(T);
    Ea_Tref = Ea_(Tref);
    R = 8.314; % J / mol / K
    EAAR = exp( - ( Ea_T / R ) .* (1./T) + ( Ea_Tref / R ) * (1/Tref) );

end