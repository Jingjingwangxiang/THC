set(0, 'defaultfigurecolor', 'w');

T = [1:100] + 273.15; % K
Tref = 25.0 + 273.15; % K

EAAR = EAAR_(T, Tref);

Arrhenius = Arrhenius_(T, Tref);

Q10 = Q10_(T, Tref);

CardinalT = CardinalT_(T, Tref);

figure;
plot(T-273.15, EAAR, 'linewidth', 8);
hold on;
plot(T-273.15, Arrhenius, 'linewidth', 8);
plot(T-273.15, Q10, 'linewidth', 8);
plot(T-273.15, CardinalT, 'linewidth', 8);
legend('EAAR', 'Arrhenius', 'Q10', 'Cardinal T', 'interpreter', 'latex');
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 64, 'TickLabelInterpreter','latex');
xlim([0 100]);
ylim([0, 5]);
xlabel('$T \: (^{\circ}C)$', 'interpreter', 'latex');
ylabel('$k/k0$', 'interpreter', 'latex');

AmpMax = 20.0; % C
Tmean = 25.0 + 273.15; % K
m = 100;
n = 100;
for i = 1:m
    Amp(i) = i * AmpMax / m;
    kEAAR(i) = 0.0;
    kArrhenius(i) = 0.0;
    kQ10(i) =  0.0;
    kCardinalT(i) = 0.0;
    for j = 1:n
        Temp = Tmean + Amp(i) * sin( 2 * pi * j / n);
        kEAAR(i) = kEAAR(i) + EAAR_(Temp, Tref);
        kArrhenius(i) = kArrhenius(i) + Arrhenius_(Temp, Tref);
        kQ10(i) = kQ10(i) + Q10_(Temp, Tref);
        kCardinalT(i) = kCardinalT(i) + CardinalT_(Temp, Tref);
    end
    kEAAR(i) = kEAAR(i) / EAAR_(Tmean, Tref) / n;
    kArrhenius(i) = kArrhenius(i) / Arrhenius_(Tmean, Tref) / n;
    kQ10(i) = kQ10(i) / Q10_(Tmean, Tref) / n;
    kCardinalT(i) = kCardinalT(i) / CardinalT_(Tmean, Tref) / n;
end

figure;
plot(Amp, kEAAR, 'linewidth', 8);
hold on;
plot(Amp, kArrhenius, 'linewidth', 8);
plot(Amp, kQ10, 'linewidth', 8);
plot(Amp, kCardinalT, 'linewidth', 8);
plot(Amp, 1.0 - 0.16 * ( ( Ea_(Tmean) / 8.314 / Tmean / Tmean ) * Amp ) + 0.42 * ( ( Ea_(Tmean) / 8.314 / Tmean / Tmean ) * Amp ).^2, ':', 'linewidth', 8);
legend('EAAR', 'Arrhenius', 'Q10', 'Cardinal T', 'Approximation', 'interpreter', 'latex');
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 64, 'TickLabelInterpreter','latex');
xlim([0, 20]);
ylim([0.9, 1.4]);
xlabel('$Temperature \: Amplitude \: (^{\circ}C)$', 'Interpreter','latex');
ylabel('$k_{eff}/k(\overline{T})$', 'interpreter', 'latex');