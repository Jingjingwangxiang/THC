function [Q10] = Q10_(T, Tref)
    
    Ea_Tref = Ea_(Tref);
    R = 8.314; % J / mol / K
    aa = Ea_Tref / R / Tref / Tref;
    Q10 =  exp( aa * ( T - Tref ) );

end