function [Arrhenius] = Arrhenius_(T, Tref)

    Ea_Tref = Ea_(Tref);
    R = 8.314; % J / mol / K
    Arrhenius = exp( - ( Ea_Tref / R ) * (1./T - 1/Tref) );

end