
set(0, 'defaultfigurecolor', 'w');

Tref = 25  + 273.15; % C
T = [1:100] + 273.15; % C
A_Tref = 1.172; % mol^{-1/2} L^{1/2}
B_Tref = 3.29; % nm^{-1} mol^{-1/2} L^{1/2}

A_T = A_Tref * Tref ./ T;
B_T = B_Tref * ( Tref ./ T ).^(1/2);

z = 1;
d = 0.3; % nm

I_1 = 1; % mol/L
Activity_1 = exp( - A_T .* z^2 .* sqrt(I_1) ./ ( 1 + B_T * d * sqrt(I_1) ) );

I_2 = 0.1; % mol/L
Activity_2 = exp( - A_T .* z^2 .* sqrt(I_2) ./ ( 1 + B_T * d * sqrt(I_2) ) );

figure; 
plot(T - 273.15, Activity_1, 'linewidth', 6);
hold on;
plot(T - 273.15, Activity_2, 'linewidth', 6);
legend('$ I=1 mol/L $', '$ I=0.1 mol/L $', 'interpreter', 'latex', 'location', 'southeast');
set(gca, 'Linewidth', 2, 'Fontweight', 'bold', 'Fontsize', 32, 'TickLabelInterpreter', 'latex');
xlabel('$T \: (^{\circ}C)$', 'Interpreter', 'latex');
ylabel('$\gamma$', 'Interpreter', 'latex');