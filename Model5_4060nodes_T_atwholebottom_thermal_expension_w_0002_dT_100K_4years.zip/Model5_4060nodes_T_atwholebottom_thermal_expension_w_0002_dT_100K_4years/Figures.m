n = importdata('output_nodal_variables_vs_x.dat');
e = importdata('output_element_materials_vs_x.dat');

WP = n(:, 1);
WP = reshape(WP, 4060, 4);
H = n(:, 4);
H = reshape(H, 4060, 4);
T = n(:, 5);
T = reshape(T, 4060, 4);
Ca = n(:, 6);
Ca = reshape(Ca, 4060, 4);
CO3 = n(:, 7);
CO3 = reshape(CO3, 4060, 4);
SO4 = n(:, 8);
SO4 = reshape(SO4, 4060, 4);
u = n(:, 9);
u = reshape(u, 4060, 4);
re1 = n(:, 10);
re1 = reshape(re1, 4060, 4);
re2 = n(:, 11);
re2 = reshape(re2, 4060, 4);

WaterDensity = e(:, 3);
WaterDensity = reshape(WaterDensity, 7876, 4);
DarcyFlux_x = e(:, 4);
DarcyFlux_x = reshape(DarcyFlux_x, 7876, 4);
DarcyFlux_y = e(:, 5);
DarcyFlux_y = reshape(DarcyFlux_y, 7876, 4);